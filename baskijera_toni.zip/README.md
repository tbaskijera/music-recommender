# Music recommender system

Built on Spotify API

## Usage

1. Create constants.py with your own credentials
2. Run `python main.py`

Some args are accepted:

- `-fetch` - to fetch more songs or not, by default `False`
- `-iterations` - fetching iterations, by default 1, doesnt take effect it `fetch` is `False`