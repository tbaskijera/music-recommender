# MongoDB client constants
MONGO_URI = 'mongodb+srv://tonibaskijera:JHgkMoWBguYGX2Ci@maincluster.wvqv6e1.mongodb.net/?retryWrites=true&w=majority'
DATABASE_NAME = 'APVO'
COLLECTION_NAME = 'songs' # or 'songs2' for testing

# Spotify client constants
CLIENT_ID = '7c0c50c4b6c9402eb1230261f1570838'
CLIENT_SECRET = '33ead8a993064eb2b6a4b680c38b5472'

## Features
AUDIO_FEATURES_LIST = [
        'danceability', 'energy', 'key', 'loudness', 'mode',
        'speechiness', 'acousticness', 'instrumentalness',
        'liveness', 'valence', 'tempo'
    ]